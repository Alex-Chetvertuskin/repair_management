# repair_management/repair/models.py

# repair/models.py
from django.db import models

class Client(models.Model):
    ID_Client = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=100)
    Phone_number = models.CharField(max_length=20)
    Email = models.EmailField()
    Address = models.CharField(max_length=100)

    def __str__(self):
        return self.Name

class Device(models.Model):
    ID_Device = models.AutoField(primary_key=True)
    ID_Client = models.ForeignKey(Client, on_delete=models.CASCADE)
    Model = models.CharField(max_length=100)
    Manufacturer = models.CharField(max_length=100)
    Date_of_manufacture = models.DateField()
    Serial_number = models.CharField(max_length=100)

    def __str__(self):
        return self.Model

class Worker(models.Model):
    ID_Worker = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=100)
    Position = models.CharField(max_length=100)
    Phone_number = models.CharField(max_length=20)
    Email = models.EmailField()
    Address = models.CharField(max_length=100)

    def __str__(self):
        return self.Name

class SparePart(models.Model):
    ID_Spare_part = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=100)
    Quantity_of_spare_parts = models.IntegerField()
    Price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.Name

class Repair(models.Model):
    ID_repair = models.AutoField(primary_key=True)
    ID_Device = models.ForeignKey(Device, on_delete=models.CASCADE)
    ID_Worker = models.ForeignKey(Worker, on_delete=models.CASCADE)
    ID_Spare_part = models.ForeignKey(SparePart, on_delete=models.CASCADE)
    Date_of_receipt = models.DateField()
    End_date = models.DateField()
    Description_of_the_problem = models.CharField(max_length=255)
    Description_of_repair = models.CharField(max_length=255)
    Price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"Repair {self.ID_repair}"
