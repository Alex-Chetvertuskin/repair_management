# repair_management/repair/views.py

from django.shortcuts import render, redirect
from .models import Client, Device, Worker, SparePart, Repair
from .forms import ClientForm, DeviceForm, WorkerForm, SparePartForm, RepairForm


def repair_home(request):
    return render(request, 'repair_home.html')

# Client views
def client_list(request):
    clients = Client.objects.all()
    return render(request, 'client_list.html', {'clients': clients})

def client_create(request):
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('client_list')
    else:
        form = ClientForm()
    return render(request, 'client_form.html', {'form': form})

def client_update(request, pk):
    client = Client.objects.get(pk=pk)
    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            return redirect('client_list')
    else:
        form = ClientForm(instance=client)
    return render(request, 'client_form.html', {'form': form})

def client_delete(request, pk):
    client = Client.objects.get(pk=pk)
    if request.method == 'POST':
        client.delete()
        return redirect('client_list')
    return render(request, 'client_confirm_delete.html', {'client': client})

# Device views
def device_list(request):
    devices = Device.objects.all()
    return render(request, 'device_list.html', {'devices': devices})

def device_create(request):
    if request.method == 'POST':
        form = DeviceForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('device_list')
    else:
        form = DeviceForm()
    return render(request, 'device_form.html', {'form': form})

def device_update(request, pk):
    device = Device.objects.get(pk=pk)
    if request.method == 'POST':
        form = DeviceForm(request.POST, instance=device)
        if form.is_valid():
            form.save()
            return redirect('device_list')
    else:
        form = DeviceForm(instance=device)
    return render(request, 'device_form.html', {'form': form})

def device_delete(request, pk):
    device = Device.objects.get(pk=pk)
    if request.method == 'POST':
        device.delete()
        return redirect('device_list')
    return render(request, 'device_confirm_delete.html', {'device': device})

# Worker views
def worker_list(request):
    workers = Worker.objects.all()
    return render(request, 'worker_list.html', {'workers': workers})

def worker_create(request):
    if request.method == 'POST':
        form = WorkerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('worker_list')
    else:
        form = WorkerForm()
    return render(request, 'worker_form.html', {'form': form})

def worker_update(request, pk):
    worker = Worker.objects.get(pk=pk)
    if request.method == 'POST':
        form = WorkerForm(request.POST, instance=worker)
        if form.is_valid():
            form.save()
            return redirect('worker_list')
    else:
        form = WorkerForm(instance=worker)
    return render(request, 'worker_form.html', {'form': form})

def worker_delete(request, pk):
    worker = Worker.objects.get(pk=pk)
    if request.method == 'POST':
        worker.delete()
        return redirect('worker_list')
    return render(request, 'worker_confirm_delete.html', {'worker': worker})

# SparePart views
def spare_part_list(request):
    spare_parts = SparePart.objects.all()
    return render(request, 'spare_part_list.html', {'spare_parts': spare_parts})

def spare_part_create(request):
    if request.method == 'POST':
        form = SparePartForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('spare_part_list')
    else:
        form = SparePartForm()
    return render(request, 'spare_part_form.html', {'form': form})

def spare_part_update(request, pk):
    spare_part = SparePart.objects.get(pk=pk)
    if request.method == 'POST':
        form = SparePartForm(request.POST, instance=spare_part)
        if form.is_valid():
            form.save()
            return redirect('spare_part_list')
    else:
        form = SparePartForm(instance=spare_part)
    return render(request, 'spare_part_form.html', {'form': form})

def spare_part_delete(request, pk):
    spare_part = SparePart.objects.get(pk=pk)
    if request.method == 'POST':
        spare_part.delete()
        return redirect('spare_part_list')
    return render(request, 'spare_part_confirm_delete.html', {'spare_part': spare_part})

# Repair views
def repair_list(request):
    repairs = Repair.objects.all()
    return render(request, 'repair_list.html', {'repairs': repairs})

def repair_create(request):
    if request.method == 'POST':
        form = RepairForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('repair_list')
    else:
        form = RepairForm()
    return render(request, 'repair_form.html', {'form': form})

def repair_update(request, pk):
    repair = Repair.objects.get(pk=pk)
    if request.method == 'POST':
        form = RepairForm(request.POST, instance=repair)
        if form.is_valid():
            form.save()
            return redirect('repair_list')
    else:
        form = RepairForm(instance=repair)
    return render(request, 'repair_form.html', {'form': form})

def repair_delete(request, pk):
    repair = Repair.objects.get(pk=pk)
    if request.method == 'POST':
        repair.delete()
        return redirect('repair_list')
    return render(request, 'repair_confirm_delete.html', {'repair': repair})
