# repair_management/repair/urls.py

# urls.py
# repair/urls.py
from django.urls import path
from . import views

app_name = 'repair'

urlpatterns = [
    path('', views.repair_home, name='repair_home'),
    path('clients/', views.client_list, name='client_list'),
    path('clients/new/', views.client_create, name='client_create'),
    path('clients/<int:pk>/edit/', views.client_update, name='client_update'),
    path('clients/<int:pk>/delete/', views.client_delete, name='client_delete'),
    path('devices/', views.device_list, name='device_list'),
    path('devices/new/', views.device_create, name='device_create'),
    path('devices/<int:pk>/edit/', views.device_update, name='device_update'),
    path('devices/<int:pk>/delete/', views.device_delete, name='device_delete'),
    path('workers/', views.worker_list, name='worker_list'),
    path('workers/new/', views.worker_create, name='worker_create'),
    path('workers/<int:pk>/edit/', views.worker_update, name='worker_update'),
    path('workers/<int:pk>/delete/', views.worker_delete, name='worker_delete'),
    path('spare_parts/', views.spare_part_list, name='spare_part_list'),
    path('spare_parts/new/', views.spare_part_create, name='spare_part_create'),
    path('spare_parts/<int:pk>/edit/', views.spare_part_update, name='spare_part_update'),
    path('spare_parts/<int:pk>/delete/', views.spare_part_delete, name='spare_part_delete'),
    path('repairs/', views.repair_list, name='repair_list'),
    path('repairs/new/', views.repair_create, name='repair_create'),
    path('repairs/<int:pk>/edit/', views.repair_update, name='repair_update'),
    path('repairs/<int:pk>/delete/', views.repair_delete, name='repair_delete'),
]
