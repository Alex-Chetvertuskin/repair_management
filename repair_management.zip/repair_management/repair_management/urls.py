# repair_management/repair_management/urls.py

# repair_management/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('repair/', include('repair.urls')),  # Include URLs from the repair app
]
